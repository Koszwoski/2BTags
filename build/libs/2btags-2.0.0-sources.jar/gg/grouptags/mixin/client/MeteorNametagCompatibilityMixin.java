package gg.grouptags.mixin.client;

import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Keeps the local player's nametag (and therefore 2BTags) visible while in
 * freecam-style cameras. 1.21.4 is after 1.21.2's render-state rewrite,
 * which added a camera-distance double parameter to shouldShowName.
 */
@Mixin(value = class_897.class, priority = 500)
abstract class MeteorNametagCompatibilityMixin {
    @Inject(method = "shouldShowName", at = @At("HEAD"), cancellable = true)
    private void grouptag$showLocalTagsInFreecam(class_1297 entity, double distance, CallbackInfoReturnable<Boolean> cir) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == entity && client.method_1560() != entity) {
            cir.setReturnValue(true);
        }
    }
}
