package gg.grouptags.mixin.client;

import gg.grouptags.client.GroupTag;
import gg.grouptags.client.GroupTagClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import net.minecraft.class_10055;
import net.minecraft.class_1007;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_742;

/**
 * 1.21.4 is after the 1.21.2 render-state rewrite but before the 1.21.9
 * SubmitNodeCollector rewrite, so PlayerRenderer already renders from a
 * cached PlayerRenderState, but renderNameTag still draws immediately via
 * PoseStack + MultiBufferSource (no submit/defer step yet).
 *
 * No poseStack.scale() is applied before re-invoking renderNameTag() -
 * vanilla computes its own above-head offset internally. The logo,
 * however, is drawn manually, so it does NOT get that offset for free -
 * we cache the player's bounding-box height in extractRenderState (where
 * the live entity is still available) and add it back in ourselves.
 */
@Mixin(class_1007.class)
abstract class PlayerRendererMixin {
    @Unique private final Map<class_10055, List<GroupTag>> grouptag$tags = new WeakHashMap<>();
    @Unique private final Map<class_10055, Float> grouptag$heights = new WeakHashMap<>();
    @Unique private boolean grouptag$rendering;

    @Shadow
    protected abstract void renderNameTag(class_10055 state, class_2561 displayName, class_4587 poseStack,
                                          class_4597 bufferSource, int packedLight);

    @Inject(method = "extractRenderState", at = @At("TAIL"))
    private void grouptag$extract(class_742 player, class_10055 state, float partialTick, CallbackInfo ci) {
        grouptag$tags.remove(state);
        grouptag$heights.remove(state);

        List<GroupTag> tags = GroupTagClient.getTags(player.method_5667());
        if (!tags.isEmpty()) {
            grouptag$tags.put(state, tags);
            grouptag$heights.put(state, player.method_17682());
        }
    }

    @Inject(method = "renderNameTag", at = @At("TAIL"))
    private void grouptag$appendTags(class_10055 state, class_2561 displayName, class_4587 poseStack,
                                     class_4597 bufferSource, int packedLight, CallbackInfo ci) {
        if (grouptag$rendering) {
            return;
        }

        List<GroupTag> tags = grouptag$tags.get(state);
        if (tags == null || tags.isEmpty()) {
            return;
        }

        float bbHeight = grouptag$heights.getOrDefault(state, 1.8F);

        grouptag$rendering = true;
        try {
            for (int index = 0; index < tags.size(); index++) {
                GroupTag tag = tags.get(index);

                // Primary (first) tag sits highest, closest to the top.
                double yOffset = 0.32D + (tags.size() - 1 - index) * 0.28D;

                poseStack.method_22903();
                poseStack.method_22904(0.0D, yOffset, 0.0D);

                class_2561 tagComponent = class_2561.method_43470(tag.name()).method_54663(tag.color() & 0xFFFFFF);
                renderNameTag(state, tagComponent, poseStack, bufferSource, packedLight);
                poseStack.method_22909();

                double logoHeight = bbHeight + 0.5D + yOffset;
                grouptag$renderLogo(tag, poseStack, bufferSource, logoHeight);
            }
        } finally {
            grouptag$rendering = false;
        }
    }

    @Unique
    private void grouptag$renderLogo(GroupTag tag, class_4587 poseStack, class_4597 bufferSource, double height) {
        GroupTagClient.getLogo(tag).ifPresent(texture -> {
            float textWidth = class_310.method_1551().field_1772.method_1727(tag.name());
            float iconX = tag.logoAfterName() ? textWidth / 2.0F + 5.0F : -textWidth / 2.0F - 5.0F;
            float halfSize = 4.0F;

            poseStack.method_22903();
            try {
                poseStack.method_22904(0.0D, height, 0.0D);
                poseStack.method_22907(class_310.method_1551().field_1773.method_19418().method_23767());
                poseStack.method_22905(0.025F, -0.025F, 0.025F);
                poseStack.method_46416(iconX, 4.0F, 0.01F);

                class_4588 consumer = bufferSource.getBuffer(class_1921.method_23028(texture));
                class_4587.class_4665 pose = poseStack.method_23760();
                consumer.method_56824(pose, -halfSize, -halfSize, 0.0F).method_39415(-1).method_22913(0.0F, 0.0F).method_60803(0xF000F0);
                consumer.method_56824(pose, -halfSize, halfSize, 0.0F).method_39415(-1).method_22913(0.0F, 1.0F).method_60803(0xF000F0);
                consumer.method_56824(pose, halfSize, halfSize, 0.0F).method_39415(-1).method_22913(1.0F, 1.0F).method_60803(0xF000F0);
                consumer.method_56824(pose, halfSize, -halfSize, 0.0F).method_39415(-1).method_22913(1.0F, 0.0F).method_60803(0xF000F0);
            } finally {
                poseStack.method_22909();
            }
        });
    }
}
