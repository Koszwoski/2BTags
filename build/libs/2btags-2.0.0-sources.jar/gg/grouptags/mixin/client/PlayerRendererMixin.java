package gg.grouptags.mixin.client;

import gg.grouptags.client.GroupTag;
import gg.grouptags.client.GroupTagClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4597;
import net.minecraft.class_742;
import net.minecraft.class_897;

/**
 * 1.21.1 predates the "render state" rewrite (introduced in 1.21.2), so
 * entities are still rendered directly and renderNameTag still takes the
 * live entity plus a trailing partialTick float that later versions drop.
 *
 * No poseStack.scale() is applied before re-invoking renderNameTag() -
 * vanilla computes its own above-head offset internally, so scaling first
 * would shrink that offset too. The logo, however, is drawn manually (not
 * via a vanilla method), so it does NOT get that above-head offset for
 * free - we have to add entity.getBbHeight() + 0.5 ourselves, matching
 * vanilla's own name-tag anchor height, on top of our extra yOffset.
 */
@Mixin(class_897.class)
abstract class PlayerRendererMixin {
    @Unique private boolean grouptag$rendering;

    @Shadow
    protected abstract void renderNameTag(class_1297 entity, class_2561 displayName, class_4587 poseStack,
                                          class_4597 bufferSource, int packedLight, float partialTick);

    @Inject(method = "renderNameTag", at = @At("TAIL"))
    private void grouptag$appendTags(class_1297 entity, class_2561 displayName, class_4587 poseStack,
                                     class_4597 bufferSource, int packedLight, float partialTick,
                                     CallbackInfo ci) {
        if (grouptag$rendering || !(entity instanceof class_742 player)) {
            return;
        }

        List<GroupTag> tags = GroupTagClient.getTags(player.method_5667());
        if (tags.isEmpty()) {
            return;
        }

        grouptag$rendering = true;
        try {
            for (int index = 0; index < tags.size(); index++) {
                GroupTag tag = tags.get(index);

                // Primary (first) tag sits highest, closest to the top.
                double yOffset = 0.32D + (tags.size() - 1 - index) * 0.28D;

                poseStack.method_22903();
                poseStack.method_22904(0.0D, yOffset, 0.0D);

                class_2561 tagComponent = class_2561.method_43470(tag.name()).method_54663(tag.color() & 0xFFFFFF);
                renderNameTag(entity, tagComponent, poseStack, bufferSource, packedLight, partialTick);
                poseStack.method_22909();

                double logoHeight = player.method_17682() + 0.5D + yOffset;
                grouptag$renderLogo(tag, poseStack, bufferSource, logoHeight);
            }
        } finally {
            grouptag$rendering = false;
        }
    }

    @Unique
    private void grouptag$renderLogo(GroupTag tag, class_4587 poseStack, class_4597 bufferSource, double height) {
        GroupTagClient.getLogo(tag).ifPresent(texture -> {
            float textWidth = class_310.method_1551().field_1772.method_1727(tag.name());
            float iconX = tag.logoAfterName() ? textWidth / 2.0F + 5.0F : -textWidth / 2.0F - 5.0F;
            float halfSize = 4.0F;

            poseStack.method_22903();
            try {
                poseStack.method_22904(0.0D, height, 0.0D);
                poseStack.method_22907(class_310.method_1551().field_1773.method_19418().method_23767());
                poseStack.method_22905(0.025F, -0.025F, 0.025F);
                poseStack.method_46416(iconX, 4.0F, 0.01F);

                class_4588 consumer = bufferSource.getBuffer(class_1921.method_23028(texture));
                class_4587.class_4665 pose = poseStack.method_23760();
                consumer.method_56824(pose, -halfSize, -halfSize, 0.0F).method_39415(-1).method_22913(0.0F, 0.0F).method_60803(0xF000F0);
                consumer.method_56824(pose, -halfSize, halfSize, 0.0F).method_39415(-1).method_22913(0.0F, 1.0F).method_60803(0xF000F0);
                consumer.method_56824(pose, halfSize, halfSize, 0.0F).method_39415(-1).method_22913(1.0F, 1.0F).method_60803(0xF000F0);
                consumer.method_56824(pose, halfSize, -halfSize, 0.0F).method_39415(-1).method_22913(1.0F, 0.0F).method_60803(0xF000F0);
            } finally {
                poseStack.method_22909();
            }
        });
    }
}
